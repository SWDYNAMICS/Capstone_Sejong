import cv2 as cv
import numpy as np
import os
import time
import math
import serial
from math import degrees,pi,atan,cos
import winsound as ws

TARGET = 'person'
TARGET_ID = 0
CONFIDENCE_THRESHOLD = 0.4   
NMS_THRESHOLD = 0.4
TANGENT = 1.6782
PIXEL_WIDTH = 1280
CAMERA_DIST = 30 #cm
FOCAL_LENGTH = PIXEL_WIDTH/TANGENT
COLORS = [(255,0,0),(255,0,255),(0, 255, 255), (255, 255, 0), (0, 255, 0), (255, 0, 0)]
GREEN =(0,255,0)
BLACK =(0,0,0)

FONTS = cv.FONT_ITALIC
class_names = []

os.chdir('C:\py_temp\Yolov4-Detector-and-Distance-Estimator-master')
with open('classes.txt', "r") as f:
    class_names = [cname.strip() for cname in f.readlines()]
#  setttng up opencv net
weight_path = 'yolov4-tiny.weights'
cfg_path = 'yolov4-tiny.cfg'

yoloNet = cv.dnn.readNet(weight_path, cfg_path)
yoloNet.setPreferableBackend(cv.dnn.DNN_BACKEND_CUDA)
yoloNet.setPreferableTarget(cv.dnn.DNN_TARGET_CUDA_FP16)

model = cv.dnn_DetectionModel(yoloNet)                                  #dnn model 
model.setInputParams(size = (416,416),scale = 1/255, swapRB =True)
arduino = serial.Serial(port = 'COM5', baudrate = 9600, timeout=2)
time.sleep(5)
#setInputParams (double scale, Size size, Scalar mean, bool swapRB, bool crop)
def object_detector(image):
    classes, scores, boxes = model.detect(image,CONFIDENCE_THRESHOLD,NMS_THRESHOLD)
    data_list =[]
    idx = np.where(classes == [TARGET_ID])[0]
    cx = list(map(lambda i: boxes[i][0]+boxes[i][2]/2,idx))
    # cx = list(map(lambda t : t[0]+t[2]/2, boxes))
        # print('idx:',i)
    cx.sort()

    for (classid, score, box) in zip(classes, scores, boxes): #zip(classes=[[67],[1],[2]]  / scores = [0.7,0.8,0.5] / boxes=[[1,2,3,4,],[5,6,7,8],[9,1,2,3]]    )
        color = COLORS[int(classid) % len(COLORS)]
        label = "%s , %f" % (class_names[classid[0]], score)
        
        cv.rectangle(image, box, color, 2)
        cv.putText(image, label, (box[0],box[1]-14), FONTS, 0.5, color, 2)

        if classid == TARGET_ID:
            data_list.append([class_names[classid[0]], cx]) 
    return data_list    #data_list [name, cx=[cx1,cx2]]

def measure_one_distance(Ax,Bx):
    #-----mesuring distance...-----
    dist = (CAMERA_DIST*PIXEL_WIDTH)/(TANGENT*abs(Ax-Bx))
    #---------------------------
    return dist

def angle_mesurement(rx,lx):
    #-----mesuring angle...-----
    ratio_rx = (PIXEL_WIDTH/2-rx)/FOCAL_LENGTH
    ratio_lx = (PIXEL_WIDTH/2-lx)/FOCAL_LENGTH
    alpha = pi/2 - atan(ratio_rx)
    beta = pi/2 - atan(ratio_lx)
    angle = (alpha + beta)/2
    #---------------------------
    return angle

def write_read(x):
    if x == '1':
        x = '01'
    x = x.encode('utf-8')
    # arduino.write(bytes(x,'utf-8'))
    arduino.write(x)
    time.sleep(0.1)
    data = arduino.readline()
    return data

def beepsound():
    fr = 2000    # range : 37 ~ 32767
    du = 1000     # 1000 ms ==1second
    ws.Beep(fr, du) # winsound.Beep(frequency, duration)

Lcap = cv.VideoCapture(0, cv.CAP_DSHOW)
Lcap.set(3,1280)
Lcap.set(4,720)

Rcap = cv.VideoCapture(1, cv.CAP_DSHOW)
Rcap.set(3,1280)
Rcap.set(4,720)

# video output frame by frame
iter = 1
while True:
    print('\n[   ',iter,"frame   ]")
    R_ret, R_frame = Rcap.read() 
    L_ret, L_frame = Lcap.read()
    if R_ret==False or L_ret==False:          
        print('We need to confirm whether both cameras work')          
        break 
    else:
        Rdata = object_detector(R_frame)
        # print("Rdata:",Rdata)
        Ldata = object_detector(L_frame)
        # print("Ldata",Ldata)
        ddx = 0
        d=[]
        angle = []
        ang = '0'
        for rd,ld in zip(Rdata,Ldata):
            if rd[0] == TARGET and ld[0] == TARGET:
                crx = rd[1][ddx]
                clx = ld[1][ddx]
                d.append(measure_one_distance(crx,clx))
                angle.append(angle_mesurement(crx,clx))
                print('Object',ddx,'crx=',crx,'clx=',clx,'dist=',"{:.2f}".format(d[ddx]),'angle=',"{:.2f}".format(degrees(angle[ddx])))
                ddx = ddx + 1
                                
            else:
                continue
        
        if len(d) >= 2:
            Angle = angle[1]-angle[0]
            dist = math.sqrt(d[0]*d[0] + d[1]*d[1] - 2*d[0]*d[1]*cos(Angle))
            print("distance between two person=","{:.2f}".format(dist))
            cv.putText(L_frame,"Distance:"+str(round(dist,3))+"Angle:"+str(degrees(round(Angle,3))),(200,50),cv.FONT_HERSHEY_SIMPLEX, 1.2, (0,0,255),2)
            
            if dist < 120:
                ang = str(int(degrees(angle[1]*(5/6))))      
                print('앙:',ang)
                beepsound()
                

        if ang != '0':
            input_data = ang
        elif ang == '0':
            input_data = '1'
        value = write_read(input_data)

        print(value)

        # if ser.readable():
        #     input_data = input_data.encode('utf-8')
        #     ser.write(input_data)
        #     time.sleep(0.1)
        # else:
        #     break

        cv.imshow('R_frame',R_frame)
        cv.imshow('L_frame',L_frame)
        iter = iter + 1
        
        key = cv.waitKey(1)        
        if key == ord('q'):
            break
Lcap.release()
Rcap.release()
cv.destroyAllWindows()